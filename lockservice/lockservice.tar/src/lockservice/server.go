// +build !sol

package lockservice

import (
	"fmt"
	"sync"
)

type LockService struct {
	mu    sync.Mutex
	locks map[string]bool
}

func NewLockService() interface{} {
	return &LockService{locks: make(map[string]bool)}
}

func (ls *LockService) Lock(request *LockRequest, response *LockResponse) error {
	ls.mu.Lock()
	defer ls.mu.Unlock()

	locked := ls.locks[request.LockName]
	if locked {
		response.Ok = false
	} else {
		ls.locks[request.LockName] = true
		response.Ok = true
	}
	return nil
}

func (ls *LockService) Unlock(request *UnlockRequest, response *UnlockResponse) error {
	return fmt.Errorf("Unimplemented")
}
