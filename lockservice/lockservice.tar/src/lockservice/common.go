// +build !sol

package lockservice

type LockRequest struct {
	LockName string
}

type LockResponse struct {
	Ok bool
}

type UnlockRequest struct {
	LockName string
}

type UnlockResponse struct {
}
