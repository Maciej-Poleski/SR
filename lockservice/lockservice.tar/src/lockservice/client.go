// +build !sol

package lockservice

import (
	"log"
	"rpcwrapper"
)

type Client struct {
	srv rpcwrapper.Client
}

func NewClient(rpcClient rpcwrapper.Client) *Client {
	return &Client{rpcClient}
}

func (c *Client) Lock(lockName string) bool {
	req := LockRequest{LockName: lockName}
	resp := LockResponse{}
	if err := c.srv.Call("LockService.Lock", &req, &resp); err != nil {
		log.Printf("got an error while locking %s: %s", lockName, err.Error())
		return false
	}
	return resp.Ok
}

func (c *Client) Unlock(lockName string) {
	log.Printf("Unlock() is not implemented")
}

func (c *Client) Close() {
	c.srv.Close()
}
